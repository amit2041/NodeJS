const server = require(".");

server.listen(3000, () => {
  console.log("server is listenening on port 3000");
});
